# Project Links

Wifi Art Projects 

* RamHouse - http://www.atelierclerici.com/ram-house 
* Wifi blocking wall paper - http://arstechnica.com/information-technology/2012/05/anti-wifi-wallpaper-lets-cellular-and-radio-through/ 
* Theriomorphous-Cyborg, Simone Ferracina - http://simoneferracina.com/Theriomorphous-Cyborg 
* Wifi Camera - http://wificamera.propositions.org.uk/ 
* Herzian Rain - Mark Shepherd - http://www.andinc.org/v4/hertzian-rain/
* Sentient City Survival Kit, Mark Shepherd - http://www.andinc.org/v4/sentient-city-survival-kit/
* Palais Des Beauxarts - http://www.palaisdesbeauxarts.at/en/


Tools
* Subnodes, Sarah Grant - http://subnod.es/
* Occupy Here, Dan Phiffer - http://occupyhere.org/ 
* SuperGlue, Danja Vasiliev, Joscha Jaeger, Michael Zeder - http://superglue.it/
* NsHey - Wifi sniffer - https://github.com/antiboredom/NSHey


Connectivity footprint


Opting Out


Media History of Wireless Technologies

* Erik Borns - history of wireless(-ness). spiritual symbolism in wireless communication tec  - http://orf.at/stories/2274986/2274848/ and in English here: http://palais-des-beaux-arts.tumblr.com/ 


#Science Links


Plants and plant research  
* plants as sensors - http://pleased-fp7.eu/?page_id=255   
* [electrical signals in plants](http://link.springer.com/chapter/10.1007/978-3-540-37843-3_17?no-access=true)  
* [potential variation in a sunflower](http://www.ncbi.nlm.nih.gov/pmc/articles/PMC158572/)  
* robots and soil monitoring  [http://www.plantoidproject.eu/index.php/the-project/project-details](http://www.plantoidproject.eu/index.php/the-project/project-details)
  
Wifi and health?  


Wifi network, operation, design etc.  



